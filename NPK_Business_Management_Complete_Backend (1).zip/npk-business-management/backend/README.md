# NPK Backend API

## Included
- FastAPI REST API with bearer-token login (JWT).
- Password hashing with PBKDF2-HMAC-SHA256.
- SQLAlchemy persistence: PostgreSQL in production; SQLite for local development.
- CRUD (create/list/read/update/delete) for employees, tasks, attendance, projects, timesheets, meetings, leaves, departments, announcements, and documents.
- Bulk creation for multiple tasks/records.
- Attendance only accepts `Present` and `Leave` (no `Absent`).
- Project stages: `Started`, `In Progress`, `Deployed`, `Completed`; completing a project forces progress to 100%.
- Timesheet hours calculated from start/end/break minutes.
- Dashboard summary endpoint and CSV exports.
- Admin user creation, activation/deactivation, and audit logs.
- Health check and interactive API docs.

## Local run
From this `backend` folder:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
set ADMIN_EMAIL=admin@example.com
set ADMIN_PASSWORD=use-a-unique-password
set JWT_SECRET=use-a-long-random-secret
uvicorn main:app --reload --port 8000
```

On Windows PowerShell use `$env:ADMIN_EMAIL="admin@example.com"` (and likewise for other variables).
Open `http://127.0.0.1:8000/docs`.

The first admin is created only if `ADMIN_EMAIL` and `ADMIN_PASSWORD` are set before the application starts. If these are missing, login will not work until an administrator has been seeded/configured. Do not use a public/default password.

## Deploy on Render
1. Push this project to GitHub.
2. In Render choose **New + → Web Service** and select the repository.
3. Set **Root Directory** to `npk-business-management/backend`.
4. Build command: `pip install -r requirements.txt`
5. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
6. Add environment variables:
   - `JWT_SECRET`: long, random, private secret.
   - `ADMIN_EMAIL`: your administrator email.
   - `ADMIN_PASSWORD`: a unique password with at least 10 characters.
   - `DATABASE_URL`: Render PostgreSQL **internal** connection URL (recommended).
   - `CORS_ORIGINS`: your deployed frontend URL, with no trailing slash. Add multiple origins separated by commas if needed.
7. Deploy. Verify `https://YOUR-BACKEND.onrender.com/api/health` and open `/docs`.

### Database persistence
For production, create a Render PostgreSQL database and use its internal URL in `DATABASE_URL`. SQLite on an ephemeral host disk can be lost when the service is redeployed/restarted. Back up the database.

## API quick reference
All routes except `/`, `/api/health`, and `/api/auth/login` require:
`Authorization: Bearer YOUR_ACCESS_TOKEN`

- `POST /api/auth/login` — JSON: `{"email":"admin@example.com","password":"..."}`
- `GET /api/auth/me`
- `POST /api/auth/change-password`
- `GET /api/dashboard`
- `GET /api/employees` (also tasks, attendance, projects, timesheets, meetings, leaves, departments, announcements, documents)
- `POST /api/tasks` — create one task
- `POST /api/tasks/bulk` — create many tasks in one request
- `GET /api/projects`
- `PATCH /api/projects/{id}` — update project status/progress
- `GET /api/attendance`
- `POST /api/attendance` — status must be `Present` or `Leave`
- `GET /api/timesheets/export.csv`
- `DELETE /api/meetings/{id}`
- `GET /api/users` — admin only
- `POST /api/users` — admin only, password minimum 10 characters
- `GET /api/audit-logs` — admin only

Example create task:
```json
{
  "title": "Prepare monthly report",
  "project": "ERP rollout",
  "assignee": "Sujith Bobba",
  "priority": "High",
  "dueDate": "2026-12-01",
  "status": "Open"
}
```

## Important frontend note
The existing website frontend was originally a browser-local prototype. This package adds a working backend API, but it does **not automatically connect the current frontend screens to this API**. Frontend JavaScript must call these endpoints, store the login token safely, and refresh tables/dashboard from the API before all edits sync between users/devices. The backend cannot write to Google Sheets unless a Google service account and Sheets integration are separately configured. PostgreSQL is the primary durable data store in this package.

## Security note
Set all production secrets in Render Environment, not in GitHub. Use HTTPS, a private/controlled frontend origin, strong passwords, backups, and review access permissions before storing real employee records.
