"""
NPK Business Solutions Pvt Ltd — API backend
FastAPI + SQLAlchemy + JWT authentication.

Persistent data is stored in DATABASE_URL (PostgreSQL recommended on Render).
For local development, SQLite is used automatically.
"""
from __future__ import annotations

import csv
import io
import os
import secrets
import hashlib
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import FastAPI, Depends, HTTPException, status, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import (
    create_engine, String, DateTime, Integer, Text, JSON, UniqueConstraint,
    select, func
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

APP_NAME = "NPK Business Solutions Pvt Ltd API"
JWT_SECRET = os.getenv("JWT_SECRET")
if not JWT_SECRET:
    # Suitable for local development only. Set a long random JWT_SECRET in production.
    JWT_SECRET = "LOCAL-ONLY-" + secrets.token_urlsafe(48)
JWT_ALGORITHM = "HS256"
TOKEN_MINUTES = int(os.getenv("TOKEN_MINUTES", "720"))
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./npk_business.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

engine_kwargs = {"pool_pre_ping": True}
if DATABASE_URL.startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}
engine = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(160), default="NPK Administrator")
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(512))
    role: Mapped[str] = mapped_column(String(40), default="admin")
    active: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Record(Base):
    __tablename__ = "records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    resource: Mapped[str] = mapped_column(String(60), index=True)
    record_key: Mapped[str] = mapped_column(String(100), index=True)
    data: Mapped[dict[str, Any]] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (UniqueConstraint("resource", "record_key", name="uq_resource_record_key"),)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_email: Mapped[str] = mapped_column(String(255), index=True)
    action: Mapped[str] = mapped_column(String(60))
    resource: Mapped[str] = mapped_column(String(60))
    record_key: Mapped[str] = mapped_column(String(100), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=APP_NAME,
    version="1.0.0",
    description="Authenticated CRUD API for NPK employee, attendance, task, project, timesheet, meeting and leave management."
)

cors_origins = [x.strip() for x in os.getenv(
    "CORS_ORIGINS",
    "http://localhost:8000,http://127.0.0.1:8000,http://localhost:3000"
).split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

security = HTTPBearer(auto_error=False)
RESOURCE_NAMES = {
    "employees", "tasks", "attendance", "projects", "timesheets",
    "meetings", "leaves", "departments", "announcements", "documents"
}
PROJECT_STAGES = {"Started", "In Progress", "Deployed", "Completed"}
ATTENDANCE_STATUSES = {"Present", "Leave"}

class LoginBody(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)

class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    email: EmailStr
    password: str = Field(min_length=10, max_length=256)
    role: str = "staff"

class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=10, max_length=256)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 310_000).hex()
    return f"pbkdf2_sha256${salt}${digest}"

def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, salt, expected = stored.split("$", 2)
        if scheme != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 310_000).hex()
        return secrets.compare_digest(actual, expected)
    except Exception:
        return False

def create_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user.id),
        "email": user.email,
        "role": user.role,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=TOKEN_MINUTES)).timestamp()),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Please sign in to continue.")
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = int(payload.get("sub", "0"))
    except (JWTError, ValueError, TypeError):
        raise HTTPException(status_code=401, detail="Session is invalid or expired. Please sign in again.")
    user = db.get(User, user_id)
    if not user or not user.active:
        raise HTTPException(status_code=401, detail="Account is inactive or unavailable.")
    return user

def admin_user(user: User = Depends(current_user)) -> User:
    if user.role not in {"admin", "super_admin"}:
        raise HTTPException(status_code=403, detail="Administrator permission required.")
    return user

def audit(db: Session, user: User, action: str, resource: str, key: str = ""):
    db.add(AuditLog(user_email=user.email, action=action, resource=resource, record_key=key))
    db.commit()

def validate_resource(resource: str):
    if resource not in RESOURCE_NAMES:
        raise HTTPException(status_code=404, detail=f"Unknown module '{resource}'. Available modules: {', '.join(sorted(RESOURCE_NAMES))}")

def normalize_data(resource: str, incoming: dict[str, Any]) -> dict[str, Any]:
    data = dict(incoming)
    if resource == "attendance":
        status_value = str(data.get("status", "Present")).strip()
        if status_value not in ATTENDANCE_STATUSES:
            raise HTTPException(status_code=422, detail="Attendance status must be Present or Leave. Absent is not supported.")
        data["status"] = status_value
    if resource == "projects":
        stage = str(data.get("status", "Started")).strip()
        if stage not in PROJECT_STAGES:
            raise HTTPException(status_code=422, detail="Project status must be Started, In Progress, Deployed, or Completed.")
        data["status"] = stage
        # Standard stage-based progress so dashboard progress follows the selected stage.
        stage_progress = {"Started": 0, "In Progress": 50, "Deployed": 85, "Completed": 100}
        if stage == "Completed":
            data["progress"] = 100
        elif "progress" not in data or data.get("progress") in (None, ""):
            data["progress"] = stage_progress[stage]
        else:
            try:
                data["progress"] = max(0, min(100, int(float(data["progress"]))))
            except (ValueError, TypeError):
                data["progress"] = stage_progress[stage]
    if resource == "timesheets":
        start, end = data.get("start"), data.get("end")
        if start and end:
            try:
                sh, sm = map(int, str(start).split(":")[:2])
                eh, em = map(int, str(end).split(":")[:2])
                minutes = eh * 60 + em - (sh * 60 + sm) - int(data.get("breakMinutes", 0) or 0)
                data["hours"] = round(max(0, minutes) / 60, 2)
            except (ValueError, TypeError):
                pass
    return data

def serialize(record: Record) -> dict[str, Any]:
    return {
        "id": record.record_key,
        **(record.data or {}),
        "_createdAt": record.created_at.isoformat() if record.created_at else None,
        "_updatedAt": record.updated_at.isoformat() if record.updated_at else None,
    }

def get_record(db: Session, resource: str, key: str) -> Record:
    row = db.scalar(select(Record).where(Record.resource == resource, Record.record_key == key))
    if not row:
        raise HTTPException(status_code=404, detail="Record not found.")
    return row

@app.get("/")
def root():
    return {"company": "NPK Business Solutions Pvt Ltd", "api": "ok", "docs": "/docs", "health": "/api/health"}

@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {"company": "NPK Business Solutions Pvt Ltd", "status": "ok", "database": "connected", "timestamp": datetime.now(timezone.utc).isoformat()}

@app.post("/api/auth/login")
def login(body: LoginBody, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not user.active or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    return {"access_token": create_token(user), "token_type": "bearer", "expires_in": TOKEN_MINUTES * 60,
            "user": {"id": user.id, "name": user.name, "email": user.email, "role": user.role}}

@app.get("/api/auth/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "name": user.name, "email": user.email, "role": user.role}

@app.post("/api/auth/change-password")
def change_password(body: PasswordChange, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(status_code=400, detail="Current password is incorrect.")
    user.password_hash = hash_password(body.new_password)
    db.commit()
    return {"message": "Password updated. Sign in again if other sessions are active."}

@app.get("/api/users")
def list_users(db: Session = Depends(get_db), _: User = Depends(admin_user)):
    users = db.scalars(select(User).order_by(User.id)).all()
    return [{"id": u.id, "name": u.name, "email": u.email, "role": u.role, "active": bool(u.active)} for u in users]

@app.post("/api/users", status_code=201)
def create_user(body: UserCreate, db: Session = Depends(get_db), _: User = Depends(admin_user)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status_code=409, detail="A user with this email already exists.")
    role = body.role if body.role in {"admin", "staff", "manager"} else "staff"
    user = User(name=body.name.strip(), email=email, password_hash=hash_password(body.password), role=role)
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"id": user.id, "name": user.name, "email": user.email, "role": user.role, "active": True}

@app.patch("/api/users/{user_id}/active")
def set_user_active(user_id: int, active: bool = Body(embed=True), db: Session = Depends(get_db), _: User = Depends(admin_user)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    user.active = 1 if active else 0
    db.commit()
    return {"id": user.id, "active": bool(user.active)}

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db), _: User = Depends(current_user)):
    rows = db.scalars(select(Record)).all()
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault(row.resource, []).append(row.data or {})
    projects = grouped.get("projects", [])
    tasks = grouped.get("tasks", [])
    employees = grouped.get("employees", [])
    attendance = grouped.get("attendance", [])
    leaves = grouped.get("leaves", [])
    return {
        "employees": {"total": len(employees)},
        "attendance": {
            "present": sum(1 for r in attendance if r.get("status") == "Present"),
            "leave": sum(1 for r in attendance if r.get("status") == "Leave"),
            "records": len(attendance),
        },
        "projects": {
            "total": len(projects),
            "started": sum(1 for r in projects if r.get("status") == "Started"),
            "inProgress": sum(1 for r in projects if r.get("status") == "In Progress"),
            "deployed": sum(1 for r in projects if r.get("status") == "Deployed"),
            "completed": sum(1 for r in projects if r.get("status") == "Completed"),
            "averageProgress": round(sum(float(r.get("progress", 0) or 0) for r in projects) / len(projects)) if projects else 0,
        },
        "tasks": {
            "total": len(tasks),
            "open": sum(1 for r in tasks if str(r.get("status", "")).lower() not in {"completed", "done"} and not r.get("done")),
            "completed": sum(1 for r in tasks if str(r.get("status", "")).lower() in {"completed", "done"} or r.get("done") is True),
        },
        "leaves": {"total": len(leaves), "pending": sum(1 for r in leaves if str(r.get("status", "Pending")).lower() == "pending")},
        "updatedAt": datetime.now(timezone.utc).isoformat(),
    }

@app.get("/api/audit-logs")
def audit_logs(limit: int = 100, db: Session = Depends(get_db), _: User = Depends(admin_user)):
    rows = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(max(1, min(limit, 500)))).all()
    return [{"id": r.id, "user": r.user_email, "action": r.action, "resource": r.resource,
             "recordId": r.record_key, "createdAt": r.created_at.isoformat()} for r in rows]

@app.get("/api/{resource}")
def list_records(resource: str, search: str | None = None, limit: int = 500, offset: int = 0,
                 db: Session = Depends(get_db), _: User = Depends(current_user)):
    validate_resource(resource)
    limit = max(1, min(limit, 1000))
    offset = max(0, offset)
    rows = db.scalars(select(Record).where(Record.resource == resource).order_by(Record.updated_at.desc()).offset(offset).limit(limit)).all()
    result = [serialize(r) for r in rows]
    if search:
        needle = search.lower()
        result = [r for r in result if needle in str(r).lower()]
    return {"items": result, "count": len(result), "resource": resource}

@app.post("/api/{resource}", status_code=201)
def create_record(resource: str, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    validate_resource(resource)
    data = normalize_data(resource, payload)
    key = str(data.pop("id", "") or secrets.token_urlsafe(12))
    if db.scalar(select(Record).where(Record.resource == resource, Record.record_key == key)):
        raise HTTPException(status_code=409, detail=f"Record id '{key}' already exists.")
    row = Record(resource=resource, record_key=key, data=data)
    db.add(row)
    db.commit()
    db.refresh(row)
    audit(db, user, "create", resource, key)
    return serialize(row)

@app.post("/api/{resource}/bulk", status_code=201)
def bulk_create(resource: str, payload: list[dict[str, Any]] = Body(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    validate_resource(resource)
    if not payload or len(payload) > 500:
        raise HTTPException(status_code=422, detail="Provide between 1 and 500 records per batch.")
    created = []
    for item in payload:
        data = normalize_data(resource, item)
        key = str(data.pop("id", "") or secrets.token_urlsafe(12))
        if db.scalar(select(Record).where(Record.resource == resource, Record.record_key == key)):
            raise HTTPException(status_code=409, detail=f"Record id '{key}' already exists.")
        row = Record(resource=resource, record_key=key, data=data)
        db.add(row)
        created.append(row)
    db.commit()
    for row in created:
        db.refresh(row)
        audit(db, user, "create", resource, row.record_key)
    return {"items": [serialize(r) for r in created], "count": len(created)}

@app.get("/api/{resource}/export.csv")
def export_csv(resource: str, db: Session = Depends(get_db), _: User = Depends(current_user)):
    validate_resource(resource)
    rows = db.scalars(select(Record).where(Record.resource == resource).order_by(Record.created_at)).all()
    data = [serialize(r) for r in rows]
    fields = sorted({k for row in data for k in row.keys()})
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(data)
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{resource}.csv"'})

@app.get("/api/{resource}/{record_id}")
def read_record(resource: str, record_id: str, db: Session = Depends(get_db), _: User = Depends(current_user)):
    validate_resource(resource)
    return serialize(get_record(db, resource, record_id))

@app.put("/api/{resource}/{record_id}")
def replace_record(resource: str, record_id: str, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    validate_resource(resource)
    row = get_record(db, resource, record_id)
    data = normalize_data(resource, payload)
    data.pop("id", None)
    row.data = data
    row.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(row)
    audit(db, user, "update", resource, record_id)
    return serialize(row)

@app.patch("/api/{resource}/{record_id}")
def patch_record(resource: str, record_id: str, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    validate_resource(resource)
    row = get_record(db, resource, record_id)
    data = dict(row.data or {})
    data.update(payload)
    data = normalize_data(resource, data)
    data.pop("id", None)
    row.data = data
    row.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(row)
    audit(db, user, "update", resource, record_id)
    return serialize(row)

@app.delete("/api/{resource}/{record_id}")
def delete_record(resource: str, record_id: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    validate_resource(resource)
    row = get_record(db, resource, record_id)
    db.delete(row)
    db.commit()
    audit(db, user, "delete", resource, record_id)
    return {"message": "Record deleted.", "id": record_id, "resource": resource}

# Seed the first administrator from Render environment variables.
# Set ADMIN_EMAIL and ADMIN_PASSWORD before deploying. No shared default password is shipped.
def seed_admin():
    email = os.getenv("ADMIN_EMAIL", "").strip().lower()
    password = os.getenv("ADMIN_PASSWORD", "")
    if not email or not password:
        return
    db = SessionLocal()
    try:
        existing = db.scalar(select(User).where(User.email == email))
        if not existing:
            user = User(
                name=os.getenv("ADMIN_NAME", "NPK Administrator"),
                email=email,
                password_hash=hash_password(password),
                role="super_admin",
                active=1,
            )
            db.add(user)
            db.commit()
    finally:
        db.close()

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    seed_admin()
